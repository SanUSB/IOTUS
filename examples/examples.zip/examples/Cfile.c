#include <stdio.h> //sanusb.org/rs/sanusb.php
#include <wiringPi.h>

// LED - pino 1 do wiringPi  � o BCM_GPIO 18 e o pino f�sico 12

#define   LED   1

int main (void)
{
   wiringPiSetup() ;
   pinMode (LED, OUTPUT) ;

   while(1)
   {
   printf ("Blink C\r\n") ;
   digitalWrite (LED, HIGH) ;   // On
   delay (100) ;                
   digitalWrite (LED, LOW) ;   // Off
   delay (100) ;
   
   system("gpio write 1 1");
   system("sleep 0.1");   
   system("gpio write 1 0");
   system("sleep 0.1");   
   }
   return 0 ;
}
